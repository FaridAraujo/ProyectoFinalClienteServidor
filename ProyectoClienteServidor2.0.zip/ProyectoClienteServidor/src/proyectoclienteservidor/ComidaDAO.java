/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoclienteservidor;
import java.sql.*;
import java.util.Scanner;
/**
 *
 * @author maria
 */
public class ComidaDAO {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/RestauranteDB";
        String user = "root";
        String password = "toby2424";

        Scanner scanner = new Scanner(System.in);

        // Solicitar al usuario los datos de la comida
        System.out.println("Ingrese el nombre de la comida:");
        String nombreComida = scanner.nextLine();

        System.out.println("Ingrese la descripción de la comida:");
        String descripcionComida = scanner.nextLine();

        System.out.println("Ingrese el precio de la comida:");
        double precioComida = Double.parseDouble(scanner.nextLine());

        System.out.println("Ingrese el ID del restaurante:");
        int idRestaurante = Integer.parseInt(scanner.nextLine());

        // Consulta SQL para insertar los datos
        String sqlInsert = "INSERT INTO Comidas (Nombre, Descripcion, Precio, ID_Restaurante) " +
                           "VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement stmtInsert = conn.prepareStatement(sqlInsert)) {

            // Establecer los valores en la base de datos
            stmtInsert.setString(1, nombreComida);
            stmtInsert.setString(2, descripcionComida);
            stmtInsert.setDouble(3, precioComida);
            stmtInsert.setInt(4, idRestaurante);

            
            int filasAfectadas = stmtInsert.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("Comida agregada con éxito.");
            } else {
                System.out.println("No se pudo agregar la comida.");
            }

            // Mostrar todos los registros de comidas
            System.out.println("\nLista de todas las comidas:");
            String sqlSelect = "SELECT c.ID_Comida, c.Nombre, c.Descripcion, c.Precio, r.Nombre AS Restaurante " +
                               "FROM Comidas c " +
                               "JOIN Restaurantes r ON c.ID_Restaurante = r.ID_Restaurante";

            try (Statement stmtSelect = conn.createStatement();
                 ResultSet rs = stmtSelect.executeQuery(sqlSelect)) {

                // Mostrar los resultados
                while (rs.next()) {
                    int idComida = rs.getInt("ID_Comida");
                    String nombre = rs.getString("Nombre");
                    String descripcion = rs.getString("Descripcion");
                    double precio = rs.getDouble("Precio");
                    String restaurante = rs.getString("Restaurante");

                    System.out.println("ID Comida: " + idComida + ", Nombre: " + nombre +
                                       ", Descripción: " + descripcion + ", Precio: " + precio +
                                       ", Restaurante: " + restaurante);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }
}

