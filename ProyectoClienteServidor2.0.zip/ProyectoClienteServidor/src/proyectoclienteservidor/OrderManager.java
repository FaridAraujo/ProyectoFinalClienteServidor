/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoclienteservidor;

import java.util.*;
import java.util.concurrent.*;

// Gestiona los pedidos y envía actualizaciones automáticas a los clientes sobre el estado de los pedidos.

public class OrderManager {
    private static final Map<Integer, String> orders = new ConcurrentHashMap<>();
    private static int orderId = 1;

    public static synchronized void processOrder(String request) {
        orders.put(orderId++, request.split(" ", 2)[1]);
    }

    public static String getOrderUpdates() {
        StringBuilder updates = new StringBuilder("Actualizaciones de pedidos:\n");
        for (Map.Entry<Integer, String> entry : orders.entrySet()) {
            updates.append("Pedido ").append(entry.getKey()).append(": ").append(entry.getValue()).append("\n");
        }
        return updates.toString();
    }
}