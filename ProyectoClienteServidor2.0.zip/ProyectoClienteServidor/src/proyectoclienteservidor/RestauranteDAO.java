/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoclienteservidor;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
/**
 *
 * @author maria
 */
public class RestauranteDAO {
    // Configuración de la conexión a la base de datos
    private static final String URL = "jdbc:mysql://localhost:3306/RestauranteDB";
    private static final String USER = "root";
    private static final String PASSWORD = "toby2424"; 

    // Método para obtener la conexión
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
    
    // Metodo para agregar un restaurante
    public static void agregarRestaurante(String nombre, String ubicacion, String telefono, String correoElectronico, String tipoComida) {
        String sql = "INSERT INTO Restaurantes (Nombre, Ubicacion, Telefono, CorreoElectronico, TipoComida) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
             
            stmt.setString(1, nombre);
            stmt.setString(2, ubicacion);
            stmt.setString(3, telefono);
            stmt.setString(4, correoElectronico);
            stmt.setString(5, tipoComida);
            stmt.executeUpdate();
            System.out.println("Restaurante agregado exitosamente.");
        } catch (SQLException e) {
            System.out.println("Error al agregar restaurante: " + e.getMessage());
        }
    }

    // Método para obtener todos los restaurantes
    public static List<String> obtenerRestaurantes() {
        List<String> restaurantes = new ArrayList<>();
        String sql = "SELECT * FROM Restaurantes";

        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                String nombre = rs.getString("Nombre");
                restaurantes.add(nombre);
            }
        } catch (SQLException e) {
            System.out.println("Error al obtener restaurantes: " + e.getMessage());
        }

        return restaurantes;
    }

    // Método para actualizar un restaurante
    public static void actualizarRestaurante(int id, String nuevoNombre, String nuevaUbicacion) {
        String sql = "UPDATE Restaurantes SET Nombre = ?, Ubicacion = ? WHERE ID_Restaurante = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nuevoNombre);
            stmt.setString(2, nuevaUbicacion);
            stmt.setInt(3, id);
            stmt.executeUpdate();
            System.out.println("Restaurante actualizado exitosamente.");
        } catch (SQLException e) {
            System.out.println("Error al actualizar restaurante: " + e.getMessage());
        }
    }

    // Método para eliminar un restaurante
    public static void eliminarRestaurante(int id) {
        String sql = "DELETE FROM Restaurantes WHERE ID_Restaurante = ?";

        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("Restaurante eliminado exitosamente.");
        } catch (SQLException e) {
            System.out.println("Error al eliminar restaurante: " + e.getMessage());
        }
    }

    // Método principal para probar las operaciones
    public static void main(String[] args) {
        // Crear un restaurante
        agregarRestaurante("pupusas mayra", "San José", "2222-3333", "contacto@pizzeria.com", "Italiana");

        // Obtener y mostrar todos los restaurantes
        List<String> restaurantes = obtenerRestaurantes();
        for (String restaurante : restaurantes) {
            System.out.println("Restaurante: " + restaurante);
        }

        // Actualizar un restaurante
        actualizarRestaurante(1, "La Nueva Pizzeria", "Heredia");

        // Eliminar un restaurante
        eliminarRestaurante(3);
    }
}
