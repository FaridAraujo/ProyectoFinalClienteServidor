/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoclienteservidor;
import java.sql.*;
import java.util.Scanner;

/**
 *
 * @author maria
 */
public class PedidoDAO {
    public static void main(String[] args) {
    // Configuración de la base de datos
    String url = "jdbc:mysql://localhost:3306/RestauranteDB";
    String user = "root";
    String password = "toby2424";

    Scanner scanner = new Scanner(System.in);

    // Solicitar al usuario los datos del pedido
    System.out.println("Ingrese el ID del Pedido");
    int ID_Pedido = Integer.parseInt(scanner.nextLine());
    
    System.out.println("Ingrese el ID del cliente:");
    String ID_Cliente = scanner.nextLine();
    
    System.out.println("Ingrese el ID del restaurante");
    double ID_restaurante = Double.parseDouble(scanner.nextLine());
    
    System.out.println("Ingrese la fecha del pedido (YYYY-MM-DD):");
    String FechaHora = scanner.nextLine();
    
    System.out.println("Ingrese el total del pedido:");
    double Total = Double.parseDouble(scanner.nextLine());  // Usar double para valores decimales

    // Consulta SQL corregida
    String sqlInsert = "INSERT INTO pedidos (ID_Pedido, ID_Cliente, Id_Restaurante, FechaHora, Total) VALUES (?, ?, ?, ?, ?)";

    try (Connection conn = DriverManager.getConnection(url, user, password);
         PreparedStatement stmtInsert = conn.prepareStatement(sqlInsert)) {

        // Establecer los valores en la base de datos
        stmtInsert.setInt(1, ID_Pedido);
        stmtInsert.setString(2, ID_Cliente);
        stmtInsert.setDouble(3, ID_restaurante);
        stmtInsert.setString(4, FechaHora);
        stmtInsert.setDouble(5, Total); 
        
        int filasAfectadas = stmtInsert.executeUpdate();

        if (filasAfectadas > 0) {
            System.out.println("Pedido agregado con éxito.");
        } else {
            System.out.println("No se pudo agregar el pedido.");
        }

        // Mostrar todos los pedidos
        System.out.println("\nLista de todos los pedidos:");
        String sqlSelect = "SELECT p.ID_Pedido, p.ID_Cliente, p.FechaHora, p.Total, c.nombre AS cliente_nombre " +
                           "FROM pedidos p " +
                           "JOIN clientes c ON p.ID_Cliente = c.ID_Cliente";

        try (Statement stmtSelect = conn.createStatement();
             ResultSet rs = stmtSelect.executeQuery(sqlSelect)) {

            // Mostrar los resultados
            while (rs.next()) {
                int idPedido = rs.getInt("ID_Pedido");
                String clienteId = rs.getString("ID_Cliente");
                String clienteNombre = rs.getString("cliente_nombre");
                String pedidoFecha = rs.getString("FechaHora");
                double pedidoTotal = rs.getDouble("Total");

                System.out.println("ID Pedido: " + idPedido + ", Cliente: " + clienteNombre +
                                   ", Fecha: " + pedidoFecha + ", Total: " + pedidoTotal);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

    } catch (SQLException e) {
        e.printStackTrace();
    } finally {
        scanner.close();
        }
    }
}

