/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoclienteservidor;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
/**
 *
 * @author maria
 */
public class ClienteDAO {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/RestauranteDB";
        String user = "root";
        String password = "toby2424";

        // Datos del cliente que vamos a agregar
        String nombre = "roberto sanches";
        String direccion = "Calle Ficticia, 123";
        String telefono = "123-456-7890";
        String correoelectronico = "juan.perez@email.com";

        
        String sql = "INSERT INTO clientes (nombre, correoelectronico, telefono, direccionentrega ) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(url, user, password);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nombre);
            stmt.setString(2, correoelectronico);
            stmt.setString(3, telefono);
            stmt.setString(4, direccion);

            
            int filasAfectadas = stmt.executeUpdate();

            if (filasAfectadas > 0) {
                System.out.println("Cliente agregado con éxito.");
            } else {
                System.out.println("No se pudo agregar el cliente.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
