/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoclienteservidor;

import java.util.*;

//Establece un sistema de autenticación básico con validación de usuarios y contraseñas.

public class AuthenticationManager {
    private static final Map<String, String> users = new HashMap<>();

    static {
        users.put("user1", "password1");
        users.put("user2", "password2");
    }

    public static String login(String request) {
        String[] parts = request.split(" ");
        String username = parts[1];
        String password = parts[2];

        if (users.containsKey(username) && users.get(username).equals(password)) {
            return "LOGIN_SUCCESS";
        } else {
            return "LOGIN_FAILED";
        }
    }
}
