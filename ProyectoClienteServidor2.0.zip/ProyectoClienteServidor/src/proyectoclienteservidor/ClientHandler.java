/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyectoclienteservidor;

import java.io.*;
import java.net.*;

//Maneja las solicitudes de los clientes en una arquitectura cliente-servidor.
// Implementa un mecanismo de actualización automática para notificar a los clientes sobre el estado de los pedidos.
// Gestiona el proceso de autenticación de los usuarios.

public class ClientHandler implements Runnable {
    private final Socket clientSocket;

    public ClientHandler(Socket socket) {
        this.clientSocket = socket;
    }

    @Override
    public void run() {
        try (
            BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
            PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true)
        ) {
            String request;
            while ((request = in.readLine()) != null) {
                if (request.startsWith("LOGIN")) {
                    out.println(AuthenticationManager.login(request));
                } else if (request.startsWith("ORDER")) {
                    OrderManager.processOrder(request);
                    out.println("Pedido recibido.");
                } else if (request.equals("UPDATE")) {
                    out.println(OrderManager.getOrderUpdates());
                }
            }
        } catch (IOException e) {
            System.err.println("Error con el cliente: " + e.getMessage());
        }
    }
}